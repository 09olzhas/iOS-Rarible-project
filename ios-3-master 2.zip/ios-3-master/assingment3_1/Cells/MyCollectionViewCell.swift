//
//  MyCollectionViewCell.swift
//  assingment3_1
//
//  Created by Arman Bimak on 05.02.2021.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myCollectionImage: UIImageView!
    
    @IBOutlet weak var myCollectionPrice: UILabel!
    @IBOutlet weak var myCollectionDescription: UILabel!
    @IBOutlet weak var myCollectionTitle: UILabel!
    @IBOutlet weak var myCollectionButton: UIButton!
    
    var index: Int = 0
    var delegate: ViewControllerDelegate?
    
    
    static let identifider = String(describing: MyCollectionViewCell.self)
    static let nib = UINib(nibName: identifider, bundle: nil)

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    @IBAction func didTapAdd(_ sender: Any) {
        delegate?.addToCart(index)
    }
    

}
