//
//  Product.swift
//  assingment3_1
//
//  Created by Arman Bimak on 03.02.2021.
//

import Foundation

struct Product {
    let ImageSource : String
    let Title : String
    let Description : String
    let Price : Double
}
