//
//  ViewController.swift
//  assingment3_1
//
//  Created by Arman Bimak on 03.02.2021.
//


import UIKit

protocol ViewControllerDelegate {
    func addToCart(_ item: Int)
}


class ViewController: UIViewController{

    @IBOutlet weak var gridView: UICollectionView!
    @IBOutlet weak var tableListView: UITableView!
    

    @IBOutlet weak var mySwitch: UISegmentedControl!
    
    var products : [Product] = []
    
    var cart : [Product] = []
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // table List View -->
        tableListView.delegate = self
        tableListView.dataSource = self
        self.DataConfigure()
        tableListView.isHidden = false
        gridView.isHidden = true
        tableListView.register(MyTableViewCell.nib, forCellReuseIdentifier: MyTableViewCell.indetifier)
        
        
        // collection View -->
        self.gridView.dataSource = self
        self.gridView.delegate = self
        self.gridView.register(MyCollectionViewCell.nib, forCellWithReuseIdentifier: MyCollectionViewCell.identifider)
        
    }

    
    @IBAction func didTapSwitch(_ sender: Any) {
        // make inverse --> should always work properly, but i am not certain
        gridView.isHidden = !gridView.isHidden
        tableListView.isHidden = !tableListView.isHidden
    }
    
    @IBAction func didTapOnCart(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(identifier: CartViewController.identifier) as? CartViewController else{
                    return
            }
        vc.cart_items = self.cart
        
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    private func DataConfigure(){
        
        let p1 = Product(ImageSource: "asus_rog", Title: "Synthwave is dead (?)", Description: "Crushed car", Price: 1)
        self.products.append(p1)
        
        let p2 = Product(ImageSource: "asus_tuf", Title: "Light My Smoke", Description: "picture", Price: 3)
        self.products.append(p2)
        
        let p3 = Product(ImageSource: "huawei_mate_book", Title: "Majestic Waterfall", Description: "nature picture", Price: 2.5)
        
        self.products.append(p3)
        
        let p4 = Product(ImageSource: "lenovo_ideapad", Title: "Jeff Benzos", Description: "picture of human", Price: 2.7)
        
        self.products.append(p4)
        
        let p5 = Product(ImageSource: "lenovo_legion", Title: "Lick", Description: "picture of girls", Price: 4)
        self.products.append(p5)
        
        let p6 = Product(ImageSource: "lenovo_v14", Title: "Tribal Mask 2", Description: "Original tribal mask", Price: 4.7)
        self.products.append(p6)
        
        let p7 = Product(ImageSource: "macbook_air", Title: "Tribal Mask 1", Description: "Original tribal mask", Price: 4.5)
        self.products.append(p7)
        
        let p8 = Product(ImageSource: "macbook_pro", Title: "The God Pan V2", Description: "picture", Price: 5.5)
        self.products.append(p8)
        
    }
    

}

extension ViewController: ViewControllerDelegate{
    func addToCart(_ item: Int) {
        let product = products[item]
        cart.append(product)
    }
    
    
}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.products.count
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = storyboard?.instantiateViewController(identifier: InfoViewController.identifier) as? InfoViewController else{
                    return
            }
        tableView.deselectRow(at: indexPath, animated: true)
        vc.item = self.products[indexPath.row]
        vc.index = indexPath.row
        vc.delegate = self
        navigationController?.pushViewController(vc, animated: true)

    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(150)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MyTableViewCell.indetifier, for: indexPath) as! MyTableViewCell
        let item = self.products[indexPath.row]
        cell.myTableCellTitle.text = item.Title
        cell.myTableCellPrice.text = String(item.Price)
        cell.MyTableCellDescription.text = item.Description
        cell.myTableCellImage.image = UIImage(named: item.ImageSource)
        cell.index = indexPath.row
        cell.delegate = self
        return cell
    }


}

extension ViewController :UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = gridView.dequeueReusableCell(withReuseIdentifier: MyCollectionViewCell.identifider, for: indexPath) as! MyCollectionViewCell
        let item = self.products[indexPath.item]
        cell.myCollectionTitle.text = item.Title
        cell.myCollectionPrice.text = String(item.Price)
        cell.myCollectionDescription.text = item.Description
        cell.myCollectionImage.image = UIImage(named: item.ImageSource)
        cell.index = indexPath.row
        cell.delegate = self
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let vc = storyboard?.instantiateViewController(identifier: InfoViewController.identifier) as? InfoViewController else{
                    return
            }
        gridView.deselectItem(at: indexPath, animated: true)
        vc.item = self.products[indexPath.row]
        vc.index = indexPath.row
        vc.delegate = self
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

extension ViewController : UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = self.view.bounds.width/2
        return CGSize(width: width, height: 200)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
}
