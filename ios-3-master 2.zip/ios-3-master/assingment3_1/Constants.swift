//
//  Constants.swift
//  assingment3_1
//
//  Created by admin on 05.02.2021.
//

import Foundation


public struct Constants {
    static var cart = [Cart]()
}


public struct Cart{
    
}
