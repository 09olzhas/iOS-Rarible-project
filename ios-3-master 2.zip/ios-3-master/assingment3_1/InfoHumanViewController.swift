//
//  InfoHumanViewController.swift
//  assingment3_1
//
//  Created by Олжас Айдархан on 14.06.2021.
//

import UIKit

class InfoHumanViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var submitButton: UIButton!
    
    @IBAction func submitButtonPressed(_ sender: Any) {
        
        _ = UIAlertController(title: "Thanks", message: "We got your payment. Please come back!", preferredStyle: .alert)
        
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
